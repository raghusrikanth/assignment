package company;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.PriorityQueue;
import java.util.Scanner;

public class readfile {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in) ;
        System.out.println("Provide file path:");
        String filepath = scanner.nextLine();
        PriorityQueue<int[]> pq = new PriorityQueue<>(
                (a,b) -> Integer.compare(a[1],b[1])
        );
        try{
            BufferedReader r;
            if (!filepath.equals("")) {
                //InputStream inputStream = new FileInputStream(filepath);
                BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(filepath));
                r = new BufferedReader(
                        new InputStreamReader(bufferedInputStream, StandardCharsets.UTF_8));
                System.out.println("Provide key value:");
                int key = scanner.nextInt();
                String line;
                while ((line = r.readLine()) != null) {
                    String[] str = line.split(" ");
                    int[] item = {Integer.valueOf(str[0]) ,Integer.valueOf(str[1])} ;
                    pq.add(item) ;
                    if(pq.size()>key)
                        pq.poll();

                }
            }
            else {
                // InputStreamReader inputStream = new InputStreamReader(System.in);
                System.out.println("Provide key value:");
                int key = scanner.nextInt();
                System.out.println("Provide file content(mention EOF in last line to end file):");
                r = new BufferedReader(
                        new InputStreamReader(System.in));
                String line;
                String EOF = "EOF";
                line = r.readLine();
                while (!line.equals("EOF") ){
                    String[] str = line.split(" ");
                    int[] item = {Integer.valueOf(str[0]) ,Integer.valueOf(str[1])} ;
                    pq.add(item) ;
                    if(pq.size()>key)
                        pq.poll();
                    line= r.readLine();
                }
            }
            System.out.println("Result:");
            while (!pq.isEmpty()) {
                System.out.println(pq.poll()[0]);
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
